// server/controllers/emailController.js

const nodemailer = require("nodemailer");
const { differenceInMonths, format } = require("date-fns");
const Customer = require("../models/Customer");
require("dotenv").config();

// Configure NodeMailer transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAILID, // Use the environment variable for email ID
    pass: process.env.EMAILPASSWORD, // Use the environment variable for email password
  },
});

// Function to send emails
const sendEmail = async (to, subject, html) => {
  const mailOptions = {
    from: "ramspa05@gmail.com",
    to,
    subject,
    html,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully!");
  } catch (error) {
    console.error("Error sending email:", error);
  }
};

// Function to calculate months passed since a given date
const monthsPassed = (date) => {
  const currentDate = new Date();
  const startDate = new Date(date);
  return differenceInMonths(currentDate, startDate);
};

// Function to send 6-month and 1-year update emails
const sendUpdateEmails = async () => {
  console.log("Calling sendUpdateEmails function...");

  try {
    const customers = await Customer.find();

    for (const customer of customers) {
      if (customer.email && customer.email.trim() !== "") {
        const sixMonthsPassed = monthsPassed(customer.doj) >= 6;
        const oneYearPassed = monthsPassed(customer.doj) >= 12;

        if (sixMonthsPassed && !customer.emailSent6Months) {
          // Send 6-month email
          const subject = "6-Month Update";
          const dojFormatted = format(new Date(customer.doj), "MMMM d, yyyy");

          const html = `
            <p>Dear ${customer.firstName},</p>
            <p>Hope this message finds you well.</p>
            <p>As you complete your 6-month milestone with Arris in the ${customer.Department} department, we want to express our gratitude for your dedication and hard work. Your contributions to the team have not gone unnoticed.</p>
            <p>We appreciate your commitment to excellence and look forward to many more months of success together. Congratulations on reaching this milestone!</p>
            <p>Best regards,</p>
            <p>The Arris Team</p>
          `;

          await sendEmail(customer.email, subject, html);

          // Update flag
          await Customer.findByIdAndUpdate(customer._id, {
            emailSent6Months: true,
          });
        }

        if (oneYearPassed && !customer.emailSent1Year) {
          // Send 1-year email
          const subject = "1-Year Update";
          const dojFormatted = format(new Date(customer.doj), "MMMM d, yyyy");

          const html = `
            <p>Dear ${customer.firstName},</p>
            <p>Congratulations on your 1-year anniversary with Arris in the ${customer.Department} department!</p>
            <p>Over the past year, your hard work and dedication have been instrumental to our success. We are grateful to have you as part of the team.</p>
            <p>Thank you for your continued commitment and contributions. Here's to many more years of collaboration and success!</p>
            <p>Best regards,</p>
            <p>The Arris Team</p>
          `;

          await sendEmail(customer.email, subject, html);

          // Update flag
          await Customer.findByIdAndUpdate(customer._id, {
            emailSent1Year: true,
          });
        }
      }
    }

    console.log("Emails sent successfully!");
  } catch (error) {
    console.error("Error in sendUpdateEmails:", error);
  }
};

module.exports = { sendUpdateEmails };
